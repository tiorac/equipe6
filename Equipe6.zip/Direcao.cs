﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Equipe6
{
    public enum Direcao
    {
        Esquerda,
        Cima,
        Direita,
        Baixo,
        CtrlZ
    }
}
